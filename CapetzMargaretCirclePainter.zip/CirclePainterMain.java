// *** Your name: Margaret Capetz
package ch6webcat;

import javax.swing.JFrame;

public class CirclePainterMain {
	
	public static void main(String[] args) {
		CirclePainterWindow window = new CirclePainterWindow();
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		window.setSize(800,600);
		window.setLocation(100, 100);
		window.setVisible(true);
	}

}
