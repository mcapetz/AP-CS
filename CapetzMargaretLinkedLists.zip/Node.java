package ch9webcat;

public class Node {
	String name; //data
	Node next; //reference to the next Node object
	
	//constructor
	public Node(String name) {
		this.name = name;
	}
}
